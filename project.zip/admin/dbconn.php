<?php 
$conn = mysqli_connect("127.0.0.1","root","root","pos_db");
?>