<?php 
$conn = mysqli_connect("localhost","kvaztcvk_root","1234567890!@#$%^&*()","kvaztcvk_pos_db");
?>